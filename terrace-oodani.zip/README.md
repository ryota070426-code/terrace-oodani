# TERRACE OODANI 公式サイト

旧大谷小学校（島根県松江市玉湯町）を活用した複合施設「TERRACE OODANI」のWebサイトです。

## ファイル構成

```
index.html        全8ページ分の中身（文章・画像の配置）
css/style.css     デザイン（色・文字・レイアウト）
js/main.js        ページ切り替え・スマホメニュー・写真スライド
images/           写真とロゴ
```

## よくある編集

| やりたいこと | 編集する場所 |
| --- | --- |
| 文章を直す | `index.html` の該当テキスト |
| 写真を差し替える | `images/` の同じ名前のファイルを上書き |
| 色を変える | `css/style.css` 冒頭の `:root`（`--navy` が差し色、`--paper` が背景） |
| 文字の大きさ・余白 | `css/style.css` の該当セクション（ファイル冒頭に目次あり） |

ページは `index.html` 内の `<div class="page-view" data-page="...">` ごとに分かれています（index / about / visit / facilities / cafe / restaurant / library / contact）。

## 確認方法

`index.html` をブラウザで開くとそのまま表示できます。
