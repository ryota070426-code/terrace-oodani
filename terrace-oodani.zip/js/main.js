// TERRACE OODANI — ページ切り替え・メニュー・写真スライド
(() => {
 const valid = new Set(['index','about','visit','facilities','cafe','restaurant','library','contact']);
 const views = [...document.querySelectorAll('.page-view')];
 const navBtn = document.querySelector('.hamburger');
 const mobileNav = document.getElementById('mobile-nav');
 function parse(){
  const m=decodeURIComponent(location.hash).match(/^#\/([a-z]+)(?:#([\w-]+))?$/);
  return {id:m&&valid.has(m[1])?m[1]:'index',anchor:m&&m[2]?m[2]:null};
 }
 let current='index';
 function show(route){
  const {id,anchor}=route || parse();
  views.forEach(v=>v.hidden=v.dataset.page!==id);
  document.querySelectorAll('.desktop-nav a, .mobile-nav a').forEach(a=>{
    const target=(a.getAttribute('href')||'').match(/^#\/([a-z]+)/)?.[1];
    a.removeAttribute('aria-current');
    if(target===(['cafe','restaurant','library'].includes(id)?'facilities':id))a.setAttribute('aria-current','page');
  });
  document.title=({index:'TERRACE OODANI',about:'校舎について',visit:'ご利用案内',facilities:'施設・店舗',cafe:'薪木café KOTA',restaurant:'火と時',library:'みんなの図書館 HYGGE',contact:'お問い合わせ'}[id]||'TERRACE OODANI')+'｜TERRACE OODANI';
  if(navBtn&&mobileNav){mobileNav.hidden=true;navBtn.setAttribute('aria-expanded','false');navBtn.setAttribute('aria-label','メニューを開く');}
  if(current!==id||!anchor){window.scrollTo({top:0,behavior:'instant'});} current=id;
  if(anchor){requestAnimationFrame(()=>document.getElementById(anchor)?.scrollIntoView({block:'start',behavior:'instant'}));}
  document.querySelectorAll('[data-cafe-gallery]').forEach(g=>g._galleryResume?.());
 }
 if(navBtn && mobileNav)navBtn.addEventListener('click',()=>{
   const open=mobileNav.hidden;mobileNav.hidden=!open;navBtn.setAttribute('aria-expanded',String(open));navBtn.setAttribute('aria-label',open?'メニューを閉じる':'メニューを開く');
 });
 document.addEventListener('click',e=>{
   const link=e.target.closest('a[href]');if(!link)return;
   if(link.getAttribute('href')==='#page-top'){e.preventDefault();window.scrollTo({top:0,behavior:'smooth'});}
   else {
     const href=link.getAttribute('href')||'';
     const m=href.match(/^#\/([a-z]+)(?:#([\w-]+))?$/);
     if(m && valid.has(m[1])){
       e.preventDefault();
       show({id:m[1],anchor:m[2]||null});
       // Keep browser Back navigation when local file URL allows fragment changes.
       if(location.protocol!=='about:' && location.hash!==href){
         try{location.hash=href;}catch(_){}
       }
     }
   }
 });
 function setupGallery(g){
   const slides=[...g.querySelectorAll('.cafe-gallery-slide')];const dots=[...g.querySelectorAll('[data-cafe-dot]')];
   if(slides.length<2)return;
   let n=0,timer=null;const reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
   function switchTo(i){n=(i+slides.length)%slides.length;slides.forEach((s,j)=>{let active=j===n;s.classList.toggle('is-current',active);s.setAttribute('aria-hidden',String(!active));});dots.forEach((d,j)=>{let active=j===n;d.classList.toggle('is-current',active);d.setAttribute('aria-current',String(active));});}
   function stop(){if(timer){clearInterval(timer);timer=null;}}
   function resume(){stop();if(reduce||document.hidden||g.closest('.page-view')?.hidden)return;timer=setInterval(()=>switchTo(n+1),5200);}
   function go(i){switchTo(i);resume();}
   g.querySelector('[data-cafe-prev]')?.addEventListener('click',()=>go(n-1));
   g.querySelector('[data-cafe-next]')?.addEventListener('click',()=>go(n+1));
   dots.forEach((d,i)=>d.addEventListener('click',()=>go(i)));
   let startX=null;
   g.addEventListener('touchstart',e=>{startX=e.touches[0]?.clientX;},{passive:true});
   g.addEventListener('touchend',e=>{if(startX===null)return;let dx=e.changedTouches[0].clientX-startX;if(Math.abs(dx)>55)go(n+(dx<0?1:-1));startX=null;},{passive:true});
   g.addEventListener('mouseenter',stop);g.addEventListener('mouseleave',resume);
   g.addEventListener('focusin',stop);g.addEventListener('focusout',e=>{if(!g.contains(e.relatedTarget))resume();});
   g._galleryResume=resume;
 }
 document.querySelectorAll('[data-cafe-gallery]').forEach(setupGallery);
 document.addEventListener('visibilitychange',()=>document.querySelectorAll('[data-cafe-gallery]').forEach(g=>g._galleryResume?.()));
 window.addEventListener('hashchange',()=>show());
 show();
})();
